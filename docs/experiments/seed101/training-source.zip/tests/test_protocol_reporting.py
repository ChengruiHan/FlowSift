import copy
from pathlib import Path

import pytest
from flowvla_rl.protocol import load_config, validate_config, planned_budget
from flowvla_rl.reporting import profile_summary, task_success

ROOT = Path(__file__).resolve().parents[1]

@pytest.mark.parametrize('method', ['full10', 'late5', 'uniform5'])
def test_method_configs(method):
    assert load_config(ROOT / 'configs' / f'{method}.yaml')['selection']['method'] == method

@pytest.mark.parametrize('section,key,value', [
    ('train','epochs',2), ('train','group_size',8), ('train','eta',0.2),
    ('train','budget_unit','updates'), ('model','denoising_steps',5),
    ('model','subdirectory','grpo-seed11-update300'), ('selection','normalize_by_selected_count',False),
])
def test_protocol_rejects_confounded_comparisons(section, key, value):
    config = load_config(ROOT / 'configs/full10.yaml')
    config[section][key] = value
    with pytest.raises(ValueError):
        validate_config(config)


def test_no_signal_does_not_launch_formal_budget():
    with pytest.raises(ValueError, match='no mixed'):
        planned_budget(0)


def test_profile_uses_cache_pair_medians_and_separates_backends():
    rows = []
    for backend, scale in [('toy_cpu', 1), ('smolvla_cuda', 100)]:
        for method, cost in [('full10', 10), ('late5', 6)]:
            rows.extend(dict(backend=backend, method=method, cache_id='0', learner_ms=scale*x)
                        for x in [cost, cost+1, cost+100])
    result = profile_summary(rows)
    late = [r for r in result if r['method']=='late5']
    assert all(r['speedup'] == pytest.approx(11/7) for r in late)
    assert {r['median_learner_ms'] for r in late} == {7, 700}


def test_task_success_requires_complete_and_unique_evaluations():
    rows = [dict(task_id=i, episode_index=j, success=j%2) for i in range(10) for j in range(20)]
    assert set(task_success(rows, 20).values()) == {0.5}
    with pytest.raises(ValueError):
        task_success(rows[:-1], 20)
    with pytest.raises(ValueError):
        task_success(rows + [rows[0]], 20)
